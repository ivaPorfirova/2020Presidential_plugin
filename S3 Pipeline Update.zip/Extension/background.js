//store url in variable
let url = window.location.href;

//log the important information to the console
chrome.storage.sync.get('userID', function(temp) {
    console.log("User ID: " + temp.userID);
    console.log("URL: " + url);
    console.log("Date: " + getDate());
  });
  
//add leading zeroes where necessary
function formatDate(s){
  if (s < 10)  {
    return "0" + s;
  }  else {
    return s;
  }
}

//get the date and time information for when the url is accessed
function getDate(){
  let d = new Date();
  let timeStamp = "";
  timeStamp += formatDate((d.getMonth() + 1)) + "/"; //add 1 to the month since it starts at 0
  timeStamp += formatDate((d.getDate())) + "/";
  timeStamp += d.getFullYear() + " ";

  timeStamp += formatDate((d.getHours())) + ":";
  timeStamp += formatDate((d.getMinutes())) + ":";
  timeStamp += formatDate((d.getSeconds()))

  return timeStamp; //return date and time
}

var script = document.createElement('script');
script.src ="aws s3";
document.getElementsByTagName('head')[0].appendChild(script);

var BucketName = "plugin-browsing-data";
var bucketRegion = "us-east-1";

var f = JSON.stringify({name: "User", recordedurl: "Google.com", time: "2:00"})

var paramsObj = {Bucket: BucketName};

AWS.config.update({
  accessKeyId: 'AKIATP6JA5Q4PBCQ37PF', secretAccessKey: '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', region: bucketRegion
});

var s3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: paramsObj
});

//function testUpload(){
//  s3.upload({
//    Key: "test-json",
//    Body: f,
//    ACL: 'public-read'
//  }, function(err, data) {
//    if (err) {
//      console.log(err);
//      return alert('There was an error uploading your photo: ', err.message);
//    }
//  });
//}

// testUpload()

var upload = AWS.S3.ManagedUpload({
    Key: "test-json",
    Body: f,
    ACL: 'public-read'
  }, function(err, data) {
    if (err) {
      console.log(err);
      return alert('There was an error uploading your photo: ', err.message);
    }
  });

upload()
