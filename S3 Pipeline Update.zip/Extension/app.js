var BucketName = "plugin-browsing-data";
var bucketRegion = "us-east-1";

var f = JSON.stringify({name: "User", recordedurl: "Google.com", time: "2:00"})

var paramsObj = {Bucket: BucketName};

AWS.config.update({
  accessKeyId: 'AKIATP6JA5Q4PBCQ37PF', secretAccessKey: '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', region: bucketRegion
});

var s3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: paramsObj
});

function testUpload(){
  s3.upload({
    Key: "test-json",
    Body: f,
    ACL: 'public-read'
  }, function(err, data) {
    if (err) {
      console.log(err);
      return alert('There was an error uploading your photo: ', err.message);
    }
  });
}